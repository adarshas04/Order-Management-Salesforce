({
    handleError: function (cmp, event, helper) {
        cmp.find('myRecordForm').showToast({
            "title": "Something has gone wrong!",
            "message": event.getParam("message"),
            "variant": "error"
        });
    },
    handleCancel: function(component, event, helper){
         component.get("v.myRecordForm").notifyClose();
    }
})