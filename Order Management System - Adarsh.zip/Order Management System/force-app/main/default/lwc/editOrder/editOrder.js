import { LightningElement, api } from 'lwc';

export default class EditOrder extends LightningElement {
    @api recordId;
}